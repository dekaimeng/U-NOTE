//
//  ViewController.swift
//  U-Note
//
//  Created by fffvg fgg on 2019/11/1.
//  Copyright © 2019 fffvg fgg. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
 
    
//    @IBAction func OP(_ sender: Any) {
//         self.performSegue(withIdentifier: "Open", sender: self)
//
//        }
//
    
  
    
    @IBAction func OpenCam(_ sender: Any) {
        self.performSegue(withIdentifier: "new", sender: self)
    }
    
    
    @IBAction func ShowClarification(_ sender: Any) {
        self.performSegue(withIdentifier: "SecondViewSegue", sender: self)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func didReceiveMemoryWarning() {
          super.didReceiveMemoryWarning()
          // Dispose of any resources that can be recreated.
      }


}

